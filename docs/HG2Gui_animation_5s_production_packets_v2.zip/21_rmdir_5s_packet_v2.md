# Animation 21 — `rmdir` — remove directory

## chapter_03 — The Infinite Directory

## Source animation sequence

A tiny hotel is marked:

`EMPTY DIRECTORY`

A demolition officer checks rooms.

Room 1: empty.

Room 2: empty.

Lobby: a figure labelled `.` points at itself.

Upstairs: another labelled `..` points out the window toward a larger hotel.

The officer studies the regulations.

A footnote reads:

**THESE DON'T COUNT.**

Both figures look offended.

The hotel vanishes.

`..` is left pointing at nothing for half a second, then hurriedly points somewhere else.

## Sequence lock

**Background:** olive green `#69784A`

**Total duration:** 20 seconds (4 × 5-second cuts)

**Unique boundary frames:** 5

## Character / prop lock

OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.

## Sequence Reference Board prompt

```text
Create a square 1:1 SEQUENCE REFERENCE BOARD for one Guide entry. This board is production reference and will not appear in the app.
Use the supplied 2005-film Guide screenshots only as visual-language references: original flat 2D vector / cut-paper / screen-printed pictograms, matte opaque geometry, economical anatomy, minimal faces and slightly imperfect print texture.
Place every recurring character and major prop from the CHARACTER LOCK below on one neutral sheet. For each recurring character show the SAME design in front view, side view and three-quarter view plus one neutral action pose. For clone bases show only the base design. For recurring props show one clean orthographic view.
Keep designs simple enough to reproduce exactly in every subsequent frame. Avoid tiny costume details that a video model will mutate.
The board itself may use small ID labels solely for production reference. Do not add entry titles or decorative UI.
This reference board is canonical. Subsequent frame/video generations must reproduce these exact designs rather than inventing variants.

CHARACTER LOCK
OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.
```

## Shared video reference language

Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

## Boundary frame map

### Frame 00 — `21_rmdir_frame_00.png`

**Used as:** Cut 01 START

A tiny hotel labeled `EMPTY DIRECTORY`. A demolition officer checks Room 1: empty; Room 2: empty.

### Frame 01 — `21_rmdir_frame_01.png`

**Used as:** Cut 01 END / Cut 02 START

Officer consulting rulebook.

### Frame 02 — `21_rmdir_frame_02.png`

**Used as:** Cut 02 END / Cut 03 START

Officer raising a demolition stamp.

### Frame 03 — `21_rmdir_frame_03.png`

**Used as:** Cut 03 END / Cut 04 START

`..` still pointing into absence.

### Frame 04 — `21_rmdir_frame_04.png`

**Used as:** Cut 04 END

Repaired hierarchy.

## Cut 01 — 00:00–05:00

**START:** `21_rmdir_frame_00.png`

**END:** `21_rmdir_frame_01.png`

A tiny hotel labeled `EMPTY DIRECTORY`. A demolition officer checks Room 1: empty; Room 2: empty. In the lobby stands a figure labeled `.`, pointing at itself. Upstairs, `..` points out a window toward a larger parent hotel. End with officer consulting rulebook.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: olive green #69784A
Character/prop lock: OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.
Reference board: use the canonical sequence reference board for Animation 21.
START FRAME: 21_rmdir_frame_00.png
END FRAME: 21_rmdir_frame_01.png

CUT 01 OF 04 — 00:00–05:00
A tiny hotel labeled `EMPTY DIRECTORY`. A demolition officer checks Room 1: empty; Room 2: empty. In the lobby stands a figure labeled `.`, pointing at itself. Upstairs, `..` points out a window toward a larger parent hotel. End with officer consulting rulebook.
```

## Cut 02 — 05:00–10:00

**START:** `21_rmdir_frame_01.png`

**END:** `21_rmdir_frame_02.png`

Rulebook footnote enlarges on screen: `THESE DON'T COUNT.` The officer looks back at `.` and `..`. Both figures cross their arms or otherwise register bureaucratic offense without facial animation. End with officer raising a demolition stamp.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: olive green #69784A
Character/prop lock: OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.
Reference board: use the canonical sequence reference board for Animation 21.
START FRAME: 21_rmdir_frame_01.png
END FRAME: 21_rmdir_frame_02.png

CUT 02 OF 04 — 05:00–10:00
Rulebook footnote enlarges on screen: `THESE DON'T COUNT.` The officer looks back at `.` and `..`. Both figures cross their arms or otherwise register bureaucratic offense without facial animation. End with officer raising a demolition stamp.
```

## Cut 03 — 10:00–15:00

**START:** `21_rmdir_frame_02.png`

**END:** `21_rmdir_frame_03.png`

The officer stamps `EMPTY`. The hotel collapses not explosively but by being cleanly removed from the diagram, leaving `.` gone with it. `..` remains for half a second pointing at the former location. End on `..` still pointing into absence.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: olive green #69784A
Character/prop lock: OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.
Reference board: use the canonical sequence reference board for Animation 21.
START FRAME: 21_rmdir_frame_02.png
END FRAME: 21_rmdir_frame_03.png

CUT 03 OF 04 — 10:00–15:00
The officer stamps `EMPTY`. The hotel collapses not explosively but by being cleanly removed from the diagram, leaving `.` gone with it. `..` remains for half a second pointing at the former location. End on `..` still pointing into absence.
```

## Cut 04 — 15:00–20:00

**START:** `21_rmdir_frame_03.png`

**END:** `21_rmdir_frame_04.png`

`..` looks at its own pointing arm, hurriedly swivels and points toward the larger parent hotel instead. The parent hotel accepts the gesture with complete indifference. Hold on repaired hierarchy.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: olive green #69784A
Character/prop lock: OFFICER_A: compact demolition officer pictogram with rectangular rulebook; DOT_A and DOTDOT_A: two simple human-like marker figures, DOT_A shorter and DOTDOT_A taller; HOTEL_A fixed block structure. Preserve exact figures until removal.
Reference board: use the canonical sequence reference board for Animation 21.
START FRAME: 21_rmdir_frame_03.png
END FRAME: 21_rmdir_frame_04.png

CUT 04 OF 04 — 15:00–20:00
`..` looks at its own pointing arm, hurriedly swivels and points toward the larger parent hotel instead. The parent hotel accepts the gesture with complete indifference. Hold on repaired hierarchy.
```
