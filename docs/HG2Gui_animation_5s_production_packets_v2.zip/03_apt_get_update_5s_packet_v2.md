# Animation 03 — `apt-get update` — refresh package indexes

## Chapter 4 — Package Management

## Source animation sequence

An elderly alien sits at a government desk.

A clerk stamps his birth certificate:

**AGE: 4**

The alien looks at his hands.

Still elderly.

The clerk stamps harder.

Nothing changes.

Cut to a terminal running:

`apt-get update`

A package list changes from `1.2` to `1.3`.

The installed package beside it remains `1.2`.

The clerk nods approvingly.

**"There. Much better."**

## Sequence lock

**Background:** powder blue `#7EA6B7`

**Total duration:** 15 seconds (3 × 5-second cuts)

**Unique boundary frames:** 4

## Character / prop lock

ALIEN_A: elderly pear-shaped alien with long narrow forearms and one drooping shoulder; CLERK_A: rigid rectangular bureaucrat with small round head and stamp arm. Preserve exact body proportions and face marks.

## Sequence Reference Board prompt

```text
Create a square 1:1 SEQUENCE REFERENCE BOARD for one Guide entry. This board is production reference and will not appear in the app.
Use the supplied 2005-film Guide screenshots only as visual-language references: original flat 2D vector / cut-paper / screen-printed pictograms, matte opaque geometry, economical anatomy, minimal faces and slightly imperfect print texture.
Place every recurring character and major prop from the CHARACTER LOCK below on one neutral sheet. For each recurring character show the SAME design in front view, side view and three-quarter view plus one neutral action pose. For clone bases show only the base design. For recurring props show one clean orthographic view.
Keep designs simple enough to reproduce exactly in every subsequent frame. Avoid tiny costume details that a video model will mutate.
The board itself may use small ID labels solely for production reference. Do not add entry titles or decorative UI.
This reference board is canonical. Subsequent frame/video generations must reproduce these exact designs rather than inventing variants.

CHARACTER LOCK
ALIEN_A: elderly pear-shaped alien with long narrow forearms and one drooping shoulder; CLERK_A: rigid rectangular bureaucrat with small round head and stamp arm. Preserve exact body proportions and face marks.
```

## Shared video reference language

Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

## Boundary frame map

### Frame 00 — `03_apt_get_update_frame_00.png`

**Used as:** Cut 01 START

Government-office tableau. An elderly alien sits at a desk.

### Frame 01 — `03_apt_get_update_frame_01.png`

**Used as:** Cut 01 END / Cut 02 START

The clerk reaching for an even larger stamp.

### Frame 02 — `03_apt_get_update_frame_02.png`

**Used as:** Cut 02 END / Cut 03 START

Old installed block unchanged.

### Frame 03 — `03_apt_get_update_frame_03.png`

**Used as:** Cut 03 END

Dryly.

## Cut 01 — 00:00–05:00

**START:** `03_apt_get_update_frame_00.png`

**END:** `03_apt_get_update_frame_01.png`

Government-office tableau. An elderly alien sits at a desk. A clerk calmly stamps a birth certificate `AGE: 4`. The alien lifts one ancient hand, looks from the hand to the certificate. The clerk stamps the paper again, harder. Nothing about the alien changes. End on the clerk reaching for an even larger stamp.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: powder blue #7EA6B7
Character/prop lock: ALIEN_A: elderly pear-shaped alien with long narrow forearms and one drooping shoulder; CLERK_A: rigid rectangular bureaucrat with small round head and stamp arm. Preserve exact body proportions and face marks.
Reference board: use the canonical sequence reference board for Animation 03.
START FRAME: 03_apt_get_update_frame_00.png
END FRAME: 03_apt_get_update_frame_01.png

CUT 01 OF 03 — 00:00–05:00
Government-office tableau. An elderly alien sits at a desk. A clerk calmly stamps a birth certificate `AGE: 4`. The alien lifts one ancient hand, looks from the hand to the certificate. The clerk stamps the paper again, harder. Nothing about the alien changes. End on the clerk reaching for an even larger stamp.
```

## Cut 02 — 05:00–10:00

**START:** `03_apt_get_update_frame_01.png`

**END:** `03_apt_get_update_frame_02.png`

Cut within same palette to a stripped-down terminal diagram: `apt-get update`. A package-index card labeled `1.2` flips to `1.3`; beside it an installed-package block stays visibly `1.2`. Repeat once with another index card to make the distinction unmistakable. End with old installed block unchanged.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: powder blue #7EA6B7
Character/prop lock: ALIEN_A: elderly pear-shaped alien with long narrow forearms and one drooping shoulder; CLERK_A: rigid rectangular bureaucrat with small round head and stamp arm. Preserve exact body proportions and face marks.
Reference board: use the canonical sequence reference board for Animation 03.
START FRAME: 03_apt_get_update_frame_01.png
END FRAME: 03_apt_get_update_frame_02.png

CUT 02 OF 03 — 05:00–10:00
Cut within same palette to a stripped-down terminal diagram: `apt-get update`. A package-index card labeled `1.2` flips to `1.3`; beside it an installed-package block stays visibly `1.2`. Repeat once with another index card to make the distinction unmistakable. End with old installed block unchanged.
```

## Cut 03 — 10:00–15:00

**START:** `03_apt_get_update_frame_02.png`

**END:** `03_apt_get_update_frame_03.png`

Return to clerk and alien in split-screen with the package diagram. Clerk nods with bureaucratic satisfaction and places a neat `THERE. MUCH BETTER.` label beneath the certificate while the alien and installed package remain exactly as old as before. Hold dryly.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: powder blue #7EA6B7
Character/prop lock: ALIEN_A: elderly pear-shaped alien with long narrow forearms and one drooping shoulder; CLERK_A: rigid rectangular bureaucrat with small round head and stamp arm. Preserve exact body proportions and face marks.
Reference board: use the canonical sequence reference board for Animation 03.
START FRAME: 03_apt_get_update_frame_02.png
END FRAME: 03_apt_get_update_frame_03.png

CUT 03 OF 03 — 10:00–15:00
Return to clerk and alien in split-screen with the package diagram. Clerk nods with bureaucratic satisfaction and places a neat `THERE. MUCH BETTER.` label beneath the certificate while the alien and installed package remain exactly as old as before. Hold dryly.
```
