# Animation 27 — `man` — manual

## Chapter 16 — Documentation

## Source animation sequence

A user opens:

`man command`

At the bottom:

`SEE ALSO: other(1)`

They follow it.

Another page points to three more.

Pages branch into a paper maze.

At the centre, the original command quietly performs the desired operation.

The user is elsewhere reading about magnetic tape.

A sign appears:

**YOU ARE HERE**

It points to the manual.

## Sequence lock

**Background:** warm cream `#C9BE9E`

**Total duration:** 15 seconds (3 × 5-second cuts)

**Unique boundary frames:** 4

## Character / prop lock

USER_A: angular human pictogram; MANUAL_PAGE_BASE: identical paper panel cloned for every manual page; COMMAND_A: tiny fixed machine/command object at maze center. Page layout may multiply; user does not redesign.

## Sequence Reference Board prompt

```text
Create a square 1:1 SEQUENCE REFERENCE BOARD for one Guide entry. This board is production reference and will not appear in the app.
Use the supplied 2005-film Guide screenshots only as visual-language references: original flat 2D vector / cut-paper / screen-printed pictograms, matte opaque geometry, economical anatomy, minimal faces and slightly imperfect print texture.
Place every recurring character and major prop from the CHARACTER LOCK below on one neutral sheet. For each recurring character show the SAME design in front view, side view and three-quarter view plus one neutral action pose. For clone bases show only the base design. For recurring props show one clean orthographic view.
Keep designs simple enough to reproduce exactly in every subsequent frame. Avoid tiny costume details that a video model will mutate.
The board itself may use small ID labels solely for production reference. Do not add entry titles or decorative UI.
This reference board is canonical. Subsequent frame/video generations must reproduce these exact designs rather than inventing variants.

CHARACTER LOCK
USER_A: angular human pictogram; MANUAL_PAGE_BASE: identical paper panel cloned for every manual page; COMMAND_A: tiny fixed machine/command object at maze center. Page layout may multiply; user does not redesign.
```

## Shared video reference language

Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

## Boundary frame map

### Frame 00 — `27_man_frame_00.png`

**Used as:** Cut 01 START

A user opens `man command`. The manual page is a clean paper panel.

### Frame 01 — `27_man_frame_01.png`

**Used as:** Cut 01 END / Cut 02 START

Three choices branching.

### Frame 02 — `27_man_frame_02.png`

**Used as:** Cut 02 END / Cut 03 START

User walking away from center.

### Frame 03 — `27_man_frame_03.png`

**Used as:** Cut 03 END

Technically accurate navigation.

## Cut 01 — 00:00–05:00

**START:** `27_man_frame_00.png`

**END:** `27_man_frame_01.png`

A user opens `man command`. The manual page is a clean paper panel. At the bottom, `SEE ALSO: other(1)` is highlighted. The user follows it; the panel slides sideways to another page with three more `SEE ALSO` arrows. End with three choices branching.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: warm cream #C9BE9E
Character/prop lock: USER_A: angular human pictogram; MANUAL_PAGE_BASE: identical paper panel cloned for every manual page; COMMAND_A: tiny fixed machine/command object at maze center. Page layout may multiply; user does not redesign.
Reference board: use the canonical sequence reference board for Animation 27.
START FRAME: 27_man_frame_00.png
END FRAME: 27_man_frame_01.png

CUT 01 OF 03 — 00:00–05:00
A user opens `man command`. The manual page is a clean paper panel. At the bottom, `SEE ALSO: other(1)` is highlighted. The user follows it; the panel slides sideways to another page with three more `SEE ALSO` arrows. End with three choices branching.
```

## Cut 02 — 05:00–10:00

**START:** `27_man_frame_01.png`

**END:** `27_man_frame_02.png`

The pages rapidly branch into a literal paper maze around the user, each corridor made of manual pages and cross-references. Keep typography mostly abstract except section labels. In a small visible window at the maze center, the original command quietly performs the desired operation by itself. End with user walking away from center.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: warm cream #C9BE9E
Character/prop lock: USER_A: angular human pictogram; MANUAL_PAGE_BASE: identical paper panel cloned for every manual page; COMMAND_A: tiny fixed machine/command object at maze center. Page layout may multiply; user does not redesign.
Reference board: use the canonical sequence reference board for Animation 27.
START FRAME: 27_man_frame_01.png
END FRAME: 27_man_frame_02.png

CUT 02 OF 03 — 05:00–10:00
The pages rapidly branch into a literal paper maze around the user, each corridor made of manual pages and cross-references. Keep typography mostly abstract except section labels. In a small visible window at the maze center, the original command quietly performs the desired operation by itself. End with user walking away from center.
```

## Cut 03 — 10:00–15:00

**START:** `27_man_frame_02.png`

**END:** `27_man_frame_03.png`

The user has wandered into a remote branch labeled `MAGNETIC TAPE`. A large `YOU ARE HERE` sign appears. Its arrow points not to the desired command, but to the current manual page. Hold on technically accurate navigation.

### Ready-to-paste video generation prompt

```text
Create one EXACTLY 5.0-second square Guide-animation cut.

REFERENCE LANGUAGE
- Use the supplied 2005-film Guide screenshots only as visual-language references: flat 2D vector / cut-paper / screen-printed pictograms, economical silhouettes, bold negative space, matte color, slightly imperfect printed edges, and dry diagrammatic staging. Create original compositions and original character designs.
- OUTPUT ASPECT RATIO: exactly 1:1. Compose for a square canvas from the beginning. No letterboxing and no cinematic crop.
- BACKGROUND: one single, flat, uninterrupted background color fills the entire square canvas from edge to edge. Use only the exact sequence background color supplied below. Do not create a second background band, top strip, bottom strip, colored edge, frame, border, matte, vignette, panel, window, chrome, or decorative perimeter.
- The HG2Gui app supplies all entry titles, tabs, chapter labels, framing and interface chrome. Therefore the animation itself must contain NO entry title, NO subject title, NO category tabs, NO header bar, NO Guide banner, NO decorative border, NO window controls and NO edge UI of any kind.
- Characters and props are flat opaque cutout shapes placed directly on the single-color background. No gradients, gloss, bloom, drop shadows, translucency, depth-of-field, photorealism or 3D rendering.
- People, aliens, files, machines and processes use deliberately economical geometric anatomy and minimal facial detail. Meaning comes from pose, scale, object relationships and necessary in-world labels rather than lip-sync or expressive acting.
- Perspective stays flattened. Diagrams may become rooms and labels may become physical objects. Motion is crisp and primarily linear: slides, pivots, hinges, flips, rotations, wipes, mechanical relabeling, flat pans and flat zooms. No camera shake, soft dissolve or bouncy modern easing.
- Comedy is dry. Nobody performs the joke for camera. The visual system simply follows the technical metaphor too literally.
- No generic outer space unless the cut specifically requires it. No neon cyberpunk, holographic HUD, glossy app interface, anime, 3D cartoon styling, cinematic lens effects, realistic terminal windows or desktop-window chrome.
- Do not invent dialogue, captions or labels beyond those explicitly required by the cut. Text that belongs to the app shell must never be painted into the animation.

CHARACTER / PROP CONTINUITY — MANDATORY
- Treat the supplied SEQUENCE REFERENCE BOARD as canonical model-sheet evidence, not inspiration. Every recurring character and prop must match it exactly: silhouette, head/body proportions, limb thickness, face marks, clothing/hat shape, color placement, prop geometry and relative scale.
- Every recurring element has a stable ID (for example USER_A, CLERK_A, FILE_A). Never redesign an ID because the pose, camera distance or scene changes. Only pose, position, orientation and allowed state may change.
- If several figures are defined as clones of one base ID, duplicate the same design exactly rather than inventing individuals.
- The provided START FRAME and END FRAME are hard visual constraints. Begin on the START FRAME composition and finish on the END FRAME composition. Animate the shortest clear transformation between them. Do not reinterpret either frame.
- The END FRAME of Cut N is literally the same image file as the START FRAME of Cut N+1. Never regenerate that shared boundary.
- When supported by the generator, attach the sequence reference board as a character/style reference in addition to the start and end frames. If a seed/model-version lock exists, keep it unchanged for every cut in the same entry, but the image references remain authoritative.

EDITING
- One major visual idea per five seconds.
- Land exactly on the supplied END FRAME by about 4.6 seconds and hold it through 5.0 seconds.
- No fade-in and no fade-out. No title card. No transition graphics. The app performs the surrounding presentation.

SEQUENCE LOCK
Background: warm cream #C9BE9E
Character/prop lock: USER_A: angular human pictogram; MANUAL_PAGE_BASE: identical paper panel cloned for every manual page; COMMAND_A: tiny fixed machine/command object at maze center. Page layout may multiply; user does not redesign.
Reference board: use the canonical sequence reference board for Animation 27.
START FRAME: 27_man_frame_02.png
END FRAME: 27_man_frame_03.png

CUT 03 OF 03 — 10:00–15:00
The user has wandered into a remote branch labeled `MAGNETIC TAPE`. A large `YOU ARE HERE` sign appears. Its arrow points not to the desired command, but to the current manual page. Hold on technically accurate navigation.
```
